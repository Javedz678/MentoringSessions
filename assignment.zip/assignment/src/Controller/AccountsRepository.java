package Controller;

import DataLayer.Database;
import Entity.Account;

import java.util.Scanner;

public class AccountsRepository {
    Database db = new Database();
    Scanner in = new Scanner(System.in);
    public void addAccount(){
        System.out.println("Enter account holders name: ");
        Scanner in = new Scanner(System.in);
        String name=in.next();
        Account a = new Account(name);
        db.setAccountsArray(a);
        System.out.println("Your Account number is: ");
        System.out.println(a.accountNumber);

    }
    public Account getAccount(){
        System.out.println("Enter Account number: ");
        int id= in.nextInt();
        Account a = db.getAccount(id);
        return a;
    }
   /* public int getBalance(){
        Account a = getAccount();
        return a.getBalance();
    }*/
    public void deposit(){
        System.out.println("Enter Account Number: ");
        int id= in.nextInt();
        Account a = db.getAccount(id);
        System.out.println("The current balence is: "+a.getBalance());
        System.out.println("Enter Money to deposit ");
        int money= in.nextInt();
        a.deposit(money);
        System.out.println("The current balence is: "+a.getBalance());
    }

    public void withdraw(){
        System.out.println("Enter Account Number: ");
        int id= in.nextInt();
        Account a = db.getAccount(id);
        System.out.println("The current balence is: "+a.getBalance());
        System.out.println("Enter Money to Withdraw ");
        int money= in.nextInt();
        if (a.getBalance()>=money){
            a.withdraw(money);
            System.out.println("The current balence is: "+a.getBalance());
        }else{
            System.out.println("Insufficient Balance!!!");
        }
    }

    public void transfer(){
        System.out.println("Enter Your Account Number: ");
        int id= in.nextInt();
        Account a = db.getAccount(id);
        System.out.println("Enter Account Number of the person you want to transfer: ");
        int id2= in.nextInt();
        try{
            Account a1 = db.getAccount(id2);
            System.out.println("Your current balence is: "+a.getBalance());
            System.out.println("Enter Money to Transfer ");
            int money= in.nextInt();
            if (a.getBalance()>=money){
                a.withdraw(money);
                a1.deposit(money);
                System.out.println("Your  balance after is: "+a.getBalance());
            }else{
                System.out.println("Insufficient Balance!!!");
            }
        }catch (IndexOutOfBoundsException e){
            System.out.println("No such account exits");
        }
    }
    public void transactions(){
        System.out.println("Enter Your Account Number: ");
        int id= in.nextInt();
        Account a = db.getAccount(id);
        System.out.println(" The transactions are: "+a.getTransactions());
    }
    public void show(){
        System.out.println("Enter Your Account Number: ");
        int id= in.nextInt();
        Account a = db.getAccount(id);
        System.out.println("The Account name: "+ a.getName()+"\nAccount Number: " +a.accountNumber+"\nBalance: "+a.getBalance());
    }
}
