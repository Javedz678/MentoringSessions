package Controller;
import DataLayer.Database;
import Entity.Account;
import java.util.ArrayList;

public class AccountsRepository {
    Database db = new Database();

    public int addAccount(String name){
        Account a = new Account(name);
        db.setAccountsArray(a);
        return a.accountNumber;
    }

    public int deposit(int id, int money){
        Account a = db.getAccount(id);
        getBalence(a);
        a.deposit(money);
        return a.getBalance();
    }

    public void withdraw(int id, int money){

        Account a = db.getAccount(id);
        getBalence(a);
        if (a.getBalance()>=money){
            a.withdraw(money);
            getBalence(a);
        }else{
            System.out.println("Insufficient Balance!!!");
        }
    }

    public void transfer(int id, int id2, int money){
        Account a = db.getAccount(id);
        try{
            Account a1 = db.getAccount(id2);

            if (a.getBalance()>=money){
                a.withdraw(money);
                a1.deposit(money);
                getBalence(a);
            }else{
                System.out.println("Insufficient Balance!!!");
            }
        }catch (IndexOutOfBoundsException e){
            System.out.println("No such account exits");
        }
    }
    public ArrayList<String> transactions(int id){

        Account a = db.getAccount(id);
        return a.getTransactions();
    }

    public String show(int id){
        Account a = db.getAccount(id);
        return "The Account name: "+ a.getName()+"\nAccount Number: " +a.accountNumber+"\nBalance: "+a.getBalance();
    }

    public String getBalence(Account a){
        return "The current balance is: "+a.getBalance();
    }
}
