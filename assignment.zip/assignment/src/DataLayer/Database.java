package DataLayer;

import Entity.Account;

import java.util.ArrayList;

public class Database {
    ArrayList<Account> accountsArray=new ArrayList<>();
    public Account getAccount(int id){
        return accountsArray.get(id);
    }

    public void setAccountsArray(Account account) {
        this.accountsArray.add(account);
    }
}
