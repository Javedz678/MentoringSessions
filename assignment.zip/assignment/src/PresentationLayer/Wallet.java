package PresentationLayer;
import Controller.AccountsRepository;

import java.util.ArrayList;
import java.util.Scanner;

public class Wallet{
    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        AccountsRepository a = new AccountsRepository();
        boolean continues = true;
        while (continues){
            System.out.println("Hello welcome to banking system");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer funds");
            System.out.println("5. Print transactions");
            System.out.println("6. View Account");
            System.out.println("7. Exit");
            int ch=in.nextInt();
            switch (ch){
                case 1:
                    System.out.println("Enter account holders name: ");

                    String name=in.next();
                    int accountNumber = a.addAccount(name);
                    System.out.println("Your Account number is: ");
                    System.out.println(accountNumber);
                    break;
                case 2:
                    System.out.println("Enter Account Number: ");
                    int id= in.nextInt();
                    System.out.println("Enter Money to deposit ");
                    int money= in.nextInt();
                    int b =a.deposit(id,money);
                    System.out.println("The current balance is: "+b);
                    break;
                case 3:
                    System.out.println("Enter Account Number: ");
                    id= in.nextInt();
                    System.out.println("Enter Money to Withdraw ");
                    money= in.nextInt();
                    a.withdraw(id,money);
                    break;
                case 4:
                    System.out.println("Enter Your Account Number: ");
                    id= in.nextInt();
                    System.out.println("Enter Account Number of the person you want to transfer: ");
                    int id2= in.nextInt();
                    System.out.println("Enter Money to Transfer ");
                    money= in.nextInt();
                    a.transfer(id,id2,money);
                    break;
                case 5:
                    System.out.println("Enter Your Account Number: ");
                    id= in.nextInt();
                    ArrayList<String> arr= a.transactions(id);
                    System.out.println(" The transactions are: ");
                    System.out.println(arr);
                    break;
                case 6:
                    System.out.println("Enter Your Account Number: ");
                    id= in.nextInt();
                    String msg =a.show(id);
                    System.out.println(msg);
                    break;
                default: continues=false;

            }
        }
    }
}