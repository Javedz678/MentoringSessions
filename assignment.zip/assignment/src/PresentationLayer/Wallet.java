package PresentationLayer;
import Controller.AccountsRepository;

import java.util.Scanner;
public class Wallet{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        AccountsRepository a = new AccountsRepository();
        boolean continues = true;
        while (continues){
            System.out.println("Hello welcome to banking system");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer funds");
            System.out.println("5. Print transactions");
            System.out.println("6. View Account");
            System.out.println("7. Exit");
            int ch=sc.nextInt();
            switch (ch){
                case 1:
                    a.addAccount();
                    break;
                case 2:
                    a.deposit();
                    break;
                case 3:
                    a.withdraw();
                    break;
                case 4:
                    a.transfer();
                    break;
                case 5:
                    a.transactions();
                    break;
                case 6:
                    a.show();
                    break;
                default: continues=false;

            }
        }
    }
}