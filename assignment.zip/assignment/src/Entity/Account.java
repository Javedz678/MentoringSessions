package Entity;

import java.util.ArrayList;

public class Account {
    String name;
    public static int accountNumber=-1;
    int balance=0;
    ArrayList<String> transactions=new ArrayList<>();

    public Account(String name) {
        this.name = name;
        accountNumber++;
    }

    public String getName() {
        return name;
    }

    public int getBalance() {
        return balance;
    }

    public ArrayList<String> getTransactions() {
        return transactions;
    }

    public void deposit(int money){
        this.balance+=money;
        String t= String.valueOf(money);
        transactions.add("++"+t);
    }

//    public void transfer(Account account,int money){
//        this.balance-=money;
//        account.deposit(money);
//        String t= String.valueOf(money);
//        transactions.add("--"+t);
//    }
    public void withdraw(int money){
        this.balance-=money;
        String t= String.valueOf(money);
        transactions.add("--"+t);
    }

    @Override
    public String toString() {
        return "Account{" +
                "name='" + name + '\'' +
                ", balance=" + balance +
                ", transactions=" + transactions +
                '}';
    }
}
